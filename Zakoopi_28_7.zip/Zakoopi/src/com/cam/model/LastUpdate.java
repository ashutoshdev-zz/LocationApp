package com.cam.model;

import java.util.ArrayList;

public class LastUpdate {

	ArrayList<LastUpdateDetail>lastUpdates=new ArrayList<LastUpdateDetail>();

	public ArrayList<LastUpdateDetail> getLastUpdates() {
		return lastUpdates;
	}

	public void setLastUpdates(ArrayList<LastUpdateDetail> lastUpdates) {
		this.lastUpdates = lastUpdates;
	}
}
