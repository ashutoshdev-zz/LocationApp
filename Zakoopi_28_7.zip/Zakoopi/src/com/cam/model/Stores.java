package com.cam.model;

import java.util.ArrayList;

public class Stores {

	ArrayList<StoreDeatil>stores=new ArrayList<StoreDeatil>();

	public ArrayList<StoreDeatil> getStores() {
		return stores;
	}

	public void setStores(ArrayList<StoreDeatil> stores) {
		this.stores = stores;
	}
}
