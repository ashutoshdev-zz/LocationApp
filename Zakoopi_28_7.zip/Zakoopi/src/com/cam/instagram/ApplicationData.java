package com.cam.instagram;

public class ApplicationData {
	public static final String CLIENT_ID = "49e37c372aea43c985aa5db3cd0779fd";
	public static final String CLIENT_SECRET = "636d34f69f964a1cb58729a373955b6c";
	public static final String CALLBACK_URL = "http://www.google.com";
}
