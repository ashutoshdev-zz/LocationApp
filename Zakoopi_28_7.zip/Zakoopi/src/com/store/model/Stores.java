package com.store.model;

public class Stores {

	StoreDetail store;

	public StoreDetail getStore() {
		return store;
	}

	public void setStore(StoreDetail store) {
		this.store = store;
	}
}
