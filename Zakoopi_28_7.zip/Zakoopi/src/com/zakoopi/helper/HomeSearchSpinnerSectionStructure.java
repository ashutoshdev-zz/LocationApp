package com.zakoopi.helper;

public class HomeSearchSpinnerSectionStructure {

	public String sectionName;
	public String sectionValue;

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public String getSectionValue() {
		return sectionValue;
	}

	public void setSectionValue(String sectionValue) {
		this.sectionValue = sectionValue;
	}

}
