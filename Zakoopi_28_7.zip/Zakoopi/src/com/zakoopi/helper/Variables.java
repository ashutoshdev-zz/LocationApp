package com.zakoopi.helper;

import java.util.ArrayList;

import android.graphics.Bitmap;

public class Variables {

	public static Bitmap imgbitmap;
	public static byte[] imgarr;
	public static Bitmap imgeffects;
	public static ArrayList<String> areaList = new ArrayList<String>();
	public static ArrayList<String> like_array = new ArrayList<String>();
}
