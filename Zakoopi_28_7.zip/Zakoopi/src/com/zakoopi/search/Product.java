package com.zakoopi.search;

import java.util.ArrayList;

public class Product {

	ArrayList<offerings> offerings;
	
	public ArrayList<offerings> getOfferings() {
		return offerings;
		
	}
	
	public void setOffer(ArrayList<offerings> offerings) {
		this.offerings = offerings;
	}
}
