package com.zakoopi.search;

import java.util.ArrayList;

public class TopMarket {

	ArrayList<marketsTop> markets;
	
	public ArrayList<marketsTop> getTopMarket() {
		return markets;
		
	} 
	
	public void setTopMarket(ArrayList<marketsTop> markets) {
		this.markets = markets;
	}
}
