package com.zakoopi.search;

import java.util.ArrayList;

public class TopTrends {
	
	ArrayList<trendsTop> trends;
	
	public ArrayList<trendsTop> getTopTrends() {
		return trends;
		
	}
	
	public void setTopTrends(ArrayList<trendsTop> trends) {
		this.trends = trends;
	}

}
