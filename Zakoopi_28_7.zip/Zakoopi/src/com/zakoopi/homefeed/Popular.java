package com.zakoopi.homefeed;

import java.util.ArrayList;

public class Popular {

	ArrayList<popularfeed>feedFeatured;

	public ArrayList<popularfeed> getFeedPopular() {
		return feedFeatured;
	}

	public void setFeedPopular(ArrayList<popularfeed> feedFeatured) {
		this.feedFeatured = feedFeatured;
	}

	
}
