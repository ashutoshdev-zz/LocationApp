package com.zakoopi.homefeed;

import java.util.ArrayList;

public class Recent {

	ArrayList<recentfeed>feedRecent;

	public ArrayList<recentfeed> getFeedRecent() {
		return feedRecent;
	}

	public void setFeedRecent(ArrayList<recentfeed> feedRecent) {
		this.feedRecent = feedRecent;
	}
}
