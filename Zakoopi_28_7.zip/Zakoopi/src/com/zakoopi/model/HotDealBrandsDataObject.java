package com.zakoopi.model;

public class HotDealBrandsDataObject {

	private String txtBrandsName;
	
	public HotDealBrandsDataObject(String txtBrandsName1) {
		txtBrandsName = txtBrandsName1;
	}
	
	public String gettxtBrandsName(){
		return txtBrandsName;
		
	}
	
	public void settxtBrandsName(String txtBrandsName) {
		this.txtBrandsName = txtBrandsName;
	}
	
}
