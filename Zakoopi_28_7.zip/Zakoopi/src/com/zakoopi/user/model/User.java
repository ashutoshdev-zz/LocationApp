package com.zakoopi.user.model;

public class User {

	UserDetails user;

	public UserDetails getUser() {
		return user;
	}

	public void setUser(UserDetails user_details) {
		this.user = user_details;
	}
}
