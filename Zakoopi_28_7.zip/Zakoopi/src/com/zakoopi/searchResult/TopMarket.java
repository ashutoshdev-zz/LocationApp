package com.zakoopi.searchResult;


public class TopMarket {

	MarketResult market;

	public MarketResult getMarket() {
		return market;
	}

	public void setMarket(MarketResult market) {
		this.market = market;
	}
	
	
	
}
