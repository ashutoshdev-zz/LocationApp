package com.zakoopi.lookbookView;

public class RecentLookbookMain {

	LookbookRecent lookbook;
	
	public LookbookRecent getLookbookRecent(){
		return lookbook;
	}
	
	public void setLookbookRecent(LookbookRecent lookbook){
		this.lookbook = lookbook;
	}
}
