package com.zakoopi.article.model;

public class ArticleMain {

	Article article;

	public Article getArticle() {
		return article;
	}

	public void setArticle(Article article) {
		this.article = article;
	}
	
}
